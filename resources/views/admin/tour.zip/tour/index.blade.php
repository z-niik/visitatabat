@extends('admin.layout/master')

@section('content')


<div class="content">


    <!--begin::Main Content-->
    <div class="main-content">
        <div class="row">
            <div class="col-12">
                <div class="toolbar-ui">
                    <h1 class="text-dark fs-5 fw-bold">داشبورد</h1>
                    <ul class="breadcrumb-ui ps-0">
                        <li><a href="index.html" title="پیشخوان">  ثبت مشخصات تور </a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="row clearfix">


        </div>

{{-- افزودن طرح --}}

<div class="row clearfix">
    <div class="col-lg-12 col-md-12">
        <div class="card">
            <div class="body">
                <form action="{{ route('store.tour') }}" id="form" method="post">
                    @csrf

                    <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <input type="text" name="start_day" class="form-control" placeholder=" تاریخ حرکت  ">
                            <span style="color:#7c7d7d;margin-right:5%;font-size:10px;font-size:10px;"> نمونه :1401/2/2</span>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <input type="text" name="name_start_day" class="form-control" placeholder=" روز حرکت ">
                            <span style="color:#7c7d7d;margin-right:5%;font-size:10px;"> نمونه : پنجشنبه  </span>
                        </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-6">
                    <div class="form-group">
                        <input type="text" name="type_going" class="form-control" placeholder=" نوع رفت ">
                        <span style="color:#7c7d7d;margin-right:5%;font-size:10px;"> نمونه : نجف سپهران هوایی  </span>
                    </div>
                        </div>
                     <div class="col-lg-6">
                    <div class="form-group">
                        <input type="text" name="type_plan" class="form-control" placeholder=" نوع برگشت ">
                        <span style="color:#7c7d7d;margin-right:5%;font-size:10px;"> نمونه : برگشت زمینی  </span>
                    </div>
                     </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-6">
                    <div class="form-group">
                        <input type="text" name="type_plan" class="form-control" placeholder="  اقامت ">
                        <span style="color:#7c7d7d;margin-right:5%;font-size:10px;"> نمونه : 4کربلا-2کاظمین/سامرا-4نجف  </span>
                    </div>
                        </div>
                        <div class="col-lg-6">
                    <div class="form-group">
                        <input type="text" name="type_code" class="form-control" placeholder=" کد سفر  ">
                        <span style="color:#7c7d7d;margin-right:5%;font-size:10px;"> نمونه :ب ج 2</span>
                    </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-6">
                    <div class="form-group">
                        <input type="text" name="price" class="form-control" placeholder="قیمت">
                        <span style="color:#7c7d7d;margin-right:5%;font-size:10px;"> نمونه :96364488</span>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <input type="text" name="state" class="form-control" placeholder="استان">
                        <span style="color:#7c7d7d;margin-right:5%;font-size:10px;"> نمونه : خراسان رضوی </span>
                    </div>
                </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-6">
                    <div class="form-group">
                        <input type="text" name="city" class="form-control" placeholder="شهر">
                        <span style="color:#7c7d7d;margin-right:5%;font-size:10px;"> نمونه :مشهد</span>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <input type="text" name="kargozar" class="form-control" placeholder="نام کارگزار">
                        <span style="color:#7c7d7d;margin-right:5%;font-size:10px;"> نمونه :پریان سیر پارسیان</span>
                    </div>
                </div>
                    </div>


                    <div class="row">
                        <div class="col-lg-6">
                    <div class="form-group">
                        <input type="text" name="group" class="form-control" placeholder=" گروه">
                        <span style="color:#7c7d7d;margin-right:5%;font-size:10px;"> نمونه : 126</span>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <input type="text" name="execute_code" class="form-control" placeholder="کد شرکت مجری ">
                        <span style="color:#7c7d7d;margin-right:5%;font-size:10px;"> نمونه :59003  </span>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <input type="text" name="execute_name" class="form-control" placeholder="نام شرکت مجری">
                        <span style="color:#7c7d7d;margin-right:5%;font-size:10px;"> نمونه :پریان سیر پارسیان</span>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <input type="text" name="hotel_najaf" class="form-control" placeholder="هتل نجف">
                        <span style="color:#7c7d7d;margin-right:5%;font-size:10px;"> نمونه :ضيوف الامام</span>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <input type="text" name="hotel_karbala" class="form-control" placeholder="هتل کربلا">
                        <span style="color:#7c7d7d;margin-right:5%;font-size:10px;"> نمونه :ضيوف الامام</span>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <input type="text" name="hotel_kazemain" class="form-control" placeholder="هتل کاظمین">
                        <span style="color:#7c7d7d;margin-right:5%;font-size:10px;"> نمونه :  ضيوف الامام</span>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <input type="text" name="address" class="form-control" placeholder="آدرس ">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <input type="text" name="num_days" class="form-control" placeholder="مدت اقامت ">
                        <span style="color:#7c7d7d;margin-right:5%;font-size:10px;"> نمونه : 8 شب</span>
                    </div>
                </div>
            </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-primary-ui">افزودن</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

    </div>
    <!--end::Main Content-->

</div>

@endsection
